# Green to Concrete Ratio > 2024-11-16 4:05pm
https://universe.roboflow.com/green-to-concrete-ratio/green-to-concrete-ratio-6ltcq

Provided by a Roboflow user
License: CC BY 4.0

