# Green to Concrete Ratio > Asritha_Dataset
https://universe.roboflow.com/green-to-concrete-ratio/green-to-concrete-ratio-6ltcq

Provided by a Roboflow user
License: CC BY 4.0

